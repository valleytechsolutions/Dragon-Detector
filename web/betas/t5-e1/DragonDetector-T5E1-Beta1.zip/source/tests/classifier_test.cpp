#include "detection.h"
#include <cassert>
#include <cstdio>

int main(){
    using namespace dragon;
    const uint8_t genetec[]={0x00,0xbf,0x15,1,2,3};
    auto a=addressHint(genetec,true,named("camera",Family::Wifi));
    assert(a.family==Family::Alpr && a.confidence==Confidence::Medium);
    assert(strstr(a.evidence,"unverified"));
    auto random=addressHint(genetec,false,{Family::Ble,Confidence::None,"none"});
    assert(random.confidence==Confidence::None);
    const uint8_t local[]={0x02,0xbf,0x15,1,2,3};
    assert(addressHint(local,true,{Family::Wifi,Confidence::None,"none"}).confidence==Confidence::None);
    const uint8_t axon[]={3,3,0x81,0xfc,3,0xff,0x4d,0x03};
    auto body=parseBle(axon,sizeof(axon));
    assert(body.valid && body.match.family==Family::Axon && body.match.confidence==Confidence::Strong);
    const uint8_t tile[]={3,3,0xed,0xfe};
    auto tracker=parseBle(tile,sizeof(tile));
    assert(tracker.valid && tracker.match.family==Family::Tile && trackerFamily(tracker.match.family));
    const uint8_t malformed[]={8,9,'b','a','d'};
    assert(!parseBle(malformed,sizeof(malformed)).valid);
    assert(!parseBle(nullptr,0).valid);
    const uint8_t unnamed[]={2,1,6};
    assert(parseBle(unnamed,sizeof(unnamed)).match.confidence==Confidence::None);
    assert(named("Flock camera",Family::Wifi).confidence==Confidence::Low);
    assert(named("Dragon Detector",Family::Ble).confidence==Confidence::None);
    char name[33];uint8_t ssid[32];memset(ssid,'A',sizeof(ssid));ssid[5]=1;
    safeText(name,sizeof(name),ssid,sizeof(ssid));assert(strlen(name)==32 && name[5]=='?');
    assert(static_cast<int8_t>(static_cast<unsigned char>(-76))==-76);
    puts("PASS: 12 classifier and adapter-input checks (ALPR, address scope, BLE evidence, bounds, RSSI)");
}
