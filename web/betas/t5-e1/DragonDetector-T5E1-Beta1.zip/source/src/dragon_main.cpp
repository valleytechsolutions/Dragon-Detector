// Dragon Detector T5-E1 beta: platform adapter and bounded touchscreen UI.
#include "tal_api.h"
#include "tal_wifi.h"
#include "tal_bluetooth.h"
#include "tkl_output.h"
#include "board_com_api.h"
#include "lvgl.h"
#include "lv_vendor.h"
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmisleading-indentation"
#include "detection.h"
#pragma GCC diagnostic pop

namespace {
constexpr unsigned CAPACITY=48;
constexpr uint32_t EXPIRE_MS=30000;
struct Contact {
    bool used, ble;
    uint8_t mac[6];
    int rssi;
    uint32_t seen;
    char name[64];
    dragon::Match match;
};
Contact contacts[CAPACITY]{};
MUTEX_HANDLE state_mutex=nullptr;
THREAD_HANDLE app_thread=nullptr;
lv_obj_t *status_label, *rows[4], *mode_label, *detail_label;
int selected[4]={-1,-1,-1,-1};
Contact visible[4]{};
unsigned mode=0; // All, signatures, ALPR/cameras, trackers
uint32_t wifi_batches=0, ble_reports=0;
int wifi_error=0, ble_error=0;
bool paused=false;
const char* modes[]={"ALL CONTACTS","SIGNATURES","ALPR / CAMERAS","TRACKERS"};

uint32_t now_ms(){return static_cast<uint32_t>(tal_system_get_millisecond());}
void observe(bool ble,const uint8_t* mac,int rssi,const char* name,dragon::Match match){
    const uint32_t now=now_ms();
    tal_mutex_lock(state_mutex);
    if(paused){tal_mutex_unlock(state_mutex);return;}
    unsigned slot=CAPACITY;
    for(unsigned i=0;i<CAPACITY;++i)
        if(contacts[i].used && contacts[i].ble==ble && !memcmp(contacts[i].mac,mac,6)){slot=i;break;}
    if(slot==CAPACITY){
        uint32_t oldest=0;
        for(unsigned i=0;i<CAPACITY;++i){
            if(!contacts[i].used){slot=i;break;}
            uint32_t age=now-contacts[i].seen;
            if(slot==CAPACITY || age>oldest){slot=i;oldest=age;}
        }
        contacts[slot]={};
    }
    Contact& c=contacts[slot];
    // Keep the best evidence across split ADV / scan-response reports.
    if(!c.used || now-c.seen>EXPIRE_MS || match.confidence>=c.match.confidence)c.match=match;
    c.used=true;c.ble=ble;c.rssi=rssi;c.seen=now;memcpy(c.mac,mac,6);
    if(name && name[0])snprintf(c.name,sizeof(c.name),"%s",name);
    tal_mutex_unlock(state_mutex);
}
void ble_event(TAL_BLE_EVT_PARAMS_T* event){
    if(!event || event->type!=TAL_BLE_EVT_ADV_REPORT)return;
    const auto& a=event->ble_event.adv_report;
    auto f=dragon::parseBle(a.p_data,a.data_len);
    if(!f.valid)return;
    // TKL carries the BLE address in controller byte order; normalize to display order.
    uint8_t mac[6];for(unsigned i=0;i<6;++i)mac[i]=a.peer_addr.addr[5-i];
    // BLE OUI hints stay disabled until the T5 adapter's address ordering has
    // been verified against a known transmitter. Payload classification works
    // independently of MAC ordering; Wi-Fi BSSIDs retain vendor matching.
    observe(true,mac,static_cast<int8_t>(a.rssi),f.name,f.match);
    tal_mutex_lock(state_mutex);++ble_reports;tal_mutex_unlock(state_mutex);
}
void wifi_event(WF_EVENT_E,void*){}
bool accept(const Contact& c){
    using dragon::Family;
    if(mode==1)return c.match.confidence!=dragon::Confidence::None;
    if(mode==2)return c.match.family==Family::Alpr || c.match.family==Family::Flock ||
        c.match.family==Family::Camera || c.match.family==Family::Ring || c.match.family==Family::Axon;
    if(mode==3)return dragon::trackerFamily(c.match.family);
    return true;
}
void close_detail(lv_event_t*){lv_obj_add_flag(detail_label,LV_OBJ_FLAG_HIDDEN);}
void show_detail(lv_event_t* e){
    unsigned index=static_cast<unsigned>(reinterpret_cast<uintptr_t>(lv_event_get_user_data(e)));
    if(index>=4 || selected[index]<0)return;
    const auto& c=visible[index];
    lv_label_set_text_fmt(detail_label,"%s\n%s\n%s\n\n%s\n\n%02X:%02X:%02X:%02X:%02X:%02X\n%d dBm | %s\n\nTap to close",
        c.name[0]?c.name:"Unnamed",dragon::familyName(c.match.family),dragon::confidenceName(c.match.confidence),
        c.match.evidence,c.mac[0],c.mac[1],c.mac[2],c.mac[3],c.mac[4],c.mac[5],c.rssi,c.ble?"BLE":"Wi-Fi");
    lv_obj_clear_flag(detail_label,LV_OBJ_FLAG_HIDDEN);
}
void next_mode(lv_event_t*){mode=(mode+1)%4;lv_label_set_text(mode_label,modes[mode]);}
void toggle_pause(lv_event_t* e){
    tal_mutex_lock(state_mutex);paused=!paused;bool p=paused;tal_mutex_unlock(state_mutex);
    lv_label_set_text(lv_obj_get_child(lv_event_get_target(e),0),p?"RESUME":"PAUSE");
}
void refresh(lv_timer_t*){
    const uint32_t now=now_ms();
    unsigned total=0,matched=0;uint32_t w,b;int we,be;bool p;
    tal_mutex_lock(state_mutex);
    for(auto& c:contacts)if(c.used && now-c.seen>EXPIRE_MS)c.used=false;
    for(unsigned j=0;j<4;++j)selected[j]=-1;
    for(unsigned i=0;i<CAPACITY;++i){
        const auto& c=contacts[i];if(!c.used)continue;++total;if(!accept(c))continue;++matched;
        for(unsigned j=0;j<4;++j){
            if(selected[j]<0 || c.rssi>contacts[selected[j]].rssi){
                for(unsigned k=3;k>j;--k){selected[k]=selected[k-1];}
                selected[j]=static_cast<int>(i);break;
            }
        }
    }
    for(unsigned j=0;j<4;++j)if(selected[j]>=0)visible[j]=contacts[selected[j]];
    w=wifi_batches;b=ble_reports;we=wifi_error;be=ble_error;p=paused;
    tal_mutex_unlock(state_mutex);
    lv_label_set_text_fmt(status_label,"%s | %u seen / %u match\nWi-Fi %lu  BLE %lu%s",
        p?"PAUSED":"SCANNING",total,matched,(unsigned long)w,(unsigned long)b,(we||be)?" | ERROR":"");
    for(unsigned j=0;j<4;++j){
        if(selected[j]<0){lv_label_set_text(rows[j],j==0?"Waiting for radio contacts...":"");continue;}
        const auto& c=visible[j];
        lv_label_set_text_fmt(rows[j],"%s  %d dBm\n%s | %s",c.name[0]?c.name:dragon::familyName(c.match.family),
            c.rssi,dragon::familyName(c.match.family),dragon::confidenceName(c.match.confidence));
    }
}
lv_obj_t* label(lv_obj_t* parent,int width,int y,const char* text){
    auto* l=lv_label_create(parent);lv_obj_set_width(l,width);lv_obj_align(l,LV_ALIGN_TOP_MID,0,y);
    lv_label_set_long_mode(l,LV_LABEL_LONG_WRAP);lv_obj_set_style_text_align(l,LV_TEXT_ALIGN_CENTER,0);
    lv_label_set_text(l,text);return l;
}
void make_ui(){
    auto* screen=lv_scr_act();lv_obj_set_style_bg_color(screen,lv_color_hex(0x05110b),0);
    lv_obj_set_style_text_color(screen,lv_color_hex(0x6bffa5),0);
    label(screen,300,35,"DRAGON DETECTOR");label(screen,290,57,"T5-E1 | BETA 1");
    status_label=label(screen,350,85,"Starting radios...");
    mode_label=label(screen,330,127,modes[0]);lv_obj_add_flag(mode_label,LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(mode_label,next_mode,LV_EVENT_CLICKED,nullptr);
    for(unsigned i=0;i<4;++i){
        rows[i]=label(screen,360,160+i*46,"");lv_obj_set_height(rows[i],43);
        lv_obj_add_flag(rows[i],LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(rows[i],show_detail,LV_EVENT_CLICKED,reinterpret_cast<void*>(static_cast<uintptr_t>(i)));
    }
    auto* button=lv_btn_create(screen);lv_obj_set_size(button,120,36);lv_obj_align(button,LV_ALIGN_TOP_MID,0,356);
    auto* t=lv_label_create(button);lv_label_set_text(t,"PAUSE");lv_obj_center(t);
    lv_obj_add_event_cb(button,toggle_pause,LV_EVENT_CLICKED,nullptr);
    label(screen,250,402,"Indicators, not identification");
    detail_label=label(screen,330,92,"");lv_obj_set_height(detail_label,285);
    lv_obj_set_style_bg_opa(detail_label,LV_OPA_COVER,0);lv_obj_set_style_bg_color(detail_label,lv_color_hex(0x05110b),0);
    lv_obj_add_flag(detail_label,LV_OBJ_FLAG_CLICKABLE);lv_obj_add_flag(detail_label,LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_event_cb(detail_label,close_detail,LV_EVENT_CLICKED,nullptr);
    lv_timer_create(refresh,500,nullptr);
}
void run(void*){
    tal_log_init(TAL_LOG_LEVEL_INFO,4096,(TAL_LOG_OUTPUT_CB)tkl_log_output);
    if(tal_mutex_create_init(&state_mutex)!=OPRT_OK){PR_ERR("Dragon: mutex initialization failed");return;}
    PR_NOTICE("Dragon Detector T5-E1 beta 1: hardware validation required");
    board_register_hardware();
    static char display_name[]=DISPLAY_NAME;
    lv_vendor_init(display_name);lv_vendor_disp_lock();make_ui();lv_vendor_disp_unlock();lv_vendor_start(5,1024*8);
    int wr=tal_wifi_init(wifi_event);
    if(wr==OPRT_OK)wr=tal_wifi_set_work_mode(WWM_STATION);
    int br=tal_ble_bt_init(TAL_BLE_ROLE_CENTRAL,ble_event);
    TAL_BLE_SCAN_PARAMS_T cfg{};cfg.type=TAL_BLE_SCAN_TYPE_PASSIVE;
    cfg.scan_interval=160;cfg.scan_window=80;cfg.timeout=0;cfg.filter_dup=0;
    bool ble_ready=br==OPRT_OK;
    if(ble_ready)br=tal_ble_scan_start(&cfg);
    bool ble_running=br==OPRT_OK;
    tal_mutex_lock(state_mutex);wifi_error=wr;ble_error=br;tal_mutex_unlock(state_mutex);
    PR_NOTICE("Dragon radio init: wifi=%d ble=%d",wr,br);
    uint32_t last_scan=now_ms()-5000;
    while(true){
        tal_mutex_lock(state_mutex);bool p=paused;tal_mutex_unlock(state_mutex);
        if(ble_ready && p==ble_running){
            int err=p?tal_ble_scan_stop():tal_ble_scan_start(&cfg);
            if(err==OPRT_OK)ble_running=!p;
            tal_mutex_lock(state_mutex);ble_error=err;tal_mutex_unlock(state_mutex);
            if(err!=OPRT_OK){PR_ERR("Dragon BLE scan transition: %d",err);tal_system_sleep(1000);}
        }
        if(!p && wr==OPRT_OK && now_ms()-last_scan>=5000){
            AP_IF_S* aps=nullptr;uint32_t count=0;int err=tal_wifi_all_ap_scan(&aps,&count);
            if(err==OPRT_OK && aps){
                for(uint32_t i=0;i<count;++i){
                    char name[33];dragon::safeText(name,sizeof(name),aps[i].ssid,aps[i].s_len>32?32:aps[i].s_len);
                    auto match=dragon::addressHint(aps[i].bssid,true,dragon::named(name,dragon::Family::Wifi));
                    observe(false,aps[i].bssid,aps[i].rssi,name,match);
                }
            }
            if(aps)tal_wifi_release_ap(aps);
            tal_mutex_lock(state_mutex);wifi_error=err;if(err==OPRT_OK)++wifi_batches;tal_mutex_unlock(state_mutex);
            if(err!=OPRT_OK)PR_ERR("Dragon Wi-Fi scan: %d",err);
            last_scan=now_ms();
        }
        tal_system_sleep(100);
    }
}
}
extern "C" void tuya_app_main(void){
    static char thread_name[]="dragon";
    THREAD_CFG_T cfg{};cfg.stackDepth=8192;cfg.priority=THREAD_PRIO_1;cfg.thrdname=thread_name;
    tal_thread_create_and_start(&app_thread,nullptr,nullptr,run,nullptr,&cfg);
}
