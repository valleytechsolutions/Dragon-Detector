# Dragon Detector — T5-E1 engineering beta 1

Target: Waveshare T5-E1-Touch-AMOLED-1.75, Tuya T5-E1 ARM processor,
466 × 466 CO5300 display and CST9217 touch. This is a separate native
TuyaOpen application, with Dragon Detector's portable signature classifiers.
It is not an ESP32 image or a feature-complete replacement for the ESP32 build.

## Implemented

- LVGL 8 touchscreen contact display with signal strength and evidence details.
- Repeated 2.4 GHz Wi-Fi AP scans (SSID and BSSID vendor hints).
- Passive legacy BLE advertisement scanning and payload classification.
- Tap the mode heading to cycle All Contacts, Signatures, ALPR / Cameras,
  and Trackers. Tap any of the four strongest matching contacts for details.
- Bounded 48-contact storage and 30-second expiry; no disk or cloud uploads.
- Pause/resume. A Wi-Fi scan already in progress may finish before BLE stops.
- Vendor power latch and long-press power button handling.

Confidence labels describe radio evidence, not proof of a device's activity.
An ALPR vendor OUI can belong to another product made by that vendor.
Wi-Fi AP scans may transmit probe requests. BLE scanning is passive and does
not pair or connect. This application does not start Tuya cloud provisioning.

## Scope and known limitations

Hardware boot, touch alignment, Wi-Fi/BLE coexistence and long-run stability
must be validated on a physical board. It has not been flashed during preparation.
Only four strongest matching contacts are shown at a time. It has a contact
interface, not the full themed ESP32 radar. Settings are not persisted.

No raw Wi-Fi management-frame analysis, disconnect-burst/SSID-conflict alerts,
BLE burst analytics, active BLE interrogation, SD logs, GPS, RTC/watch faces,
theme transfer, web dashboard, audio alerts or calibrated battery UI in beta 1.
Wi-Fi Remote ID is not captured by AP scans. BLE Remote ID classification can
occur for supported legacy advertisements; no drone telemetry screen is included.
Extended BLE advertisements and scan-response-only signatures are not covered.
BLE vendor OUI hints are deliberately disabled until T5 address byte ordering
is checked against a known transmitter. The displayed BLE address ordering is
provisional. Wi-Fi OUI hints are enabled.

## Reproduce

1. Clone https://github.com/tuya/TuyaOpen at
   `2ea7925824db95dac5d42d7fa4e09ef8cc3c1e90` and initialize submodules.
2. Copy this application directory to `apps/dragon_detector` in that SDK.
3. Run the SDK's `export.ps1` on Windows or `export.sh` on Linux/macOS.
4. From the app directory run
   `tos.py config choice -c WAVESHARE_T5AI_TOUCH_AMOLED_1_75.config`.
5. The SDK prepares platform/T5AI at
   `69793c66bebf58ef4f886282626c2ea96a28f9a2`. Apply the supplied
   `t5-platform-beta1.patch` inside that platform repository before the final
   build. It fixes the vendor scan-result leak and Windows build command limits.
6. On Windows set `$env:PYTHONUTF8='1'` and
   `$env:PYTHONIOENCODING='utf-8'` for the vendor packaging scripts.
   Run `tos.py build`. Check the log for success and the actual images in `dist/`;
   this SDK's wrapper can return zero even when Ninja reports an error.

The classifier headers are exact copies from the local DragonBall-Z-Radar
working tree when this port was started (repository HEAD
`8365b25be3c6baa3f77060163af2bc6dd2693d87`, with existing local modifications).
Use the included source files and manifest hashes for the exact beta snapshot.
OpenDroneID is included with its Apache-2.0 license and provenance; application
and Dragon Detector classifier code retain the original MIT license.

Native checks: compile `src/opendroneid.c` as C, then link it with
`tests/classifier_test.cpp` as C++17 using `include/` as an include directory.
Run the resulting executable. These checks do not establish hardware operation.

## Physical validation

1. Preserve the board's original firmware and RF calibration before testing.
2. Boot: confirm the Dragon Detector beta heading, readable screen, and touch.
3. Confirm Wi-Fi scan and BLE report counters increase around known devices.
4. Compare SSID, signal strength and BLE address with a known transmitter.
5. Cycle all four modes; open/close evidence; pause and resume scanning.
6. Remove transmitters and confirm expiry after 30 seconds. Run for at least
   30 minutes while checking logs/free memory, then test power-button handling.

Hardware: https://www.waveshare.com/wiki/T5-E1-Touch-AMOLED-1.75
Flash tool: https://github.com/tuya/tyutool
