Waveshare ESP32-P4 Knob 1.75X | Dragon Detector 0.14.8

Extract the contents of this ZIP to the root of a FAT32 microSD card.
Merge the folders with your existing card and keep your personal files.
Insert the card before booting or restart the device after copying the files.

dragon/resources/ contains the lookup files for vendor and Bluetooth names.
music/ and audio/ accept your own MP3 or WAV files for the Music Library.
recordings/ is where Voice Recorder saves WAV recordings.

Find both tools in Utilities > Activity.
